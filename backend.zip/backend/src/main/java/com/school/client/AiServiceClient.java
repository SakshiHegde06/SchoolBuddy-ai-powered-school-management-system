package com.school.client;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.client.WebClient;

import java.util.Map;

// Thin wrapper around the Python FastAPI service. Only the backend calls
// this — never the frontend directly (see Phase 1 architecture notes).
// Endpoints here are stubs; they'll be filled in during Phase 5 once the
// AI service exposes /predict/performance etc.
@Component
@RequiredArgsConstructor
public class AiServiceClient {

    private final WebClient aiServiceWebClient;

    public Map<String, Object> getPerformancePrediction(String studentId) {
        return aiServiceWebClient.post()
                .uri("/predict/performance")
                .bodyValue(Map.of("studentId", studentId))
                .retrieve()
                .bodyToMono(Map.class)
                .block();
    }
}